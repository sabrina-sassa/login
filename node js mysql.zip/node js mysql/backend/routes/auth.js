const express=require('express')
const authcontroller=require('../controller/auth')

const routes =express.Router()


routes.post("/register",authcontroller.register)


module.exports=routes