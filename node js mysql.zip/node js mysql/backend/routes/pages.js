const express=require('express')

const routes =express.Router()

routes.get("/",(req,res)=>{
    //res.send("home page")
    res.render("index")
})

routes.get("/register",(req,res)=>{
    //res.send("home page")
    res.render("register")
})


module.exports=routes